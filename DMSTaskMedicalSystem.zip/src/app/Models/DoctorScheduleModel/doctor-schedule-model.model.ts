export class DoctorScheduleModel {
    ScheduleId?:number;
    Day:number;
    FromHour:number;
    ToHour:number;
    DocId?:number;
}
