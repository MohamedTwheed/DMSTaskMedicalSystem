import { DoctorScheduleModel } from './doctor-schedule-model.model';

describe('DoctorScheduleModel', () => {
  it('should create an instance', () => {
    expect(new DoctorScheduleModel()).toBeTruthy();
  });
});
