import { DoctorModel } from './doctor-model.model';

describe('DoctorModel', () => {
  it('should create an instance', () => {
    expect(new DoctorModel()).toBeTruthy();
  });
});
